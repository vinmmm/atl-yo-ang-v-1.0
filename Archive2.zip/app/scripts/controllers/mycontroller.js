'use strict';

/**
 * @ngdoc function
 * @name atlApp.controller:MycontrollerCtrl
 * @description
 * # MycontrollerCtrl
 * Controller of the atlApp
 */
angular.module('atlApp')
  .controller('MycontrollerCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });

