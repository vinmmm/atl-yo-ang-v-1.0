'use strict';

/**
 * @ngdoc function
 * @name atlApp.controller:ProjectCtrl
 * @description
 * # ProjectCtrl
 * Controller of the atlApp
 */
angular.module('atlApp')
  .controller('ProjectCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
