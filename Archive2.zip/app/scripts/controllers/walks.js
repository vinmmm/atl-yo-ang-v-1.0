'use strict';

/**
 * @ngdoc function
 * @name atlApp.controller:WalksCtrl
 * @description
 * # WalksCtrl
 * Controller of the atlApp
 */
angular.module('atlApp')
  .controller('WalksCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
