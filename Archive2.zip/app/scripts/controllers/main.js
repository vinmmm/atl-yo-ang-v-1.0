'use strict';

/**
 * @ngdoc function
 * @name atlApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the atlApp
 */
angular.module('atlApp')
  .controller('MainCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
